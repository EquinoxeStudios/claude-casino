    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-links">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'menu_class' => 'footer-menu',
                    'container' => false,
                    'fallback_cb' => 'midnightravencasino_footer_fallback_menu'
                ));
                ?>
            </div>
            <div class="footer-bottom">
                <div class="disclaimer">
                    <strong>Disclaimer (18+ / Play Responsibly)</strong>
                    <p>This free‑to‑play social‑casino site is intended for persons aged 18 years and older (or the legal gambling age in your jurisdiction).</p>
                    <p>No real‑money gambling: all games use virtual currency only and do not offer prizes of real‑world value.</p>
                    <p>Optional in‑app purchases of virtual coins may be available.</p>
                    <p>Success at social‑casino games does not imply future success at real‑money gambling.</p>
                    <span>If you or someone you know has a gambling problem, please seek help at <a href="https://www.begambleaware.org" target="_blank" rel="noopener">www.begambleaware.org</a> or call 1‑800‑522‑4700.</span>
                </div>
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/base.js"></script>
    <?php wp_footer(); ?>
</body>
</html>

<style>
/* Footer Menu Styling */
.footer-menu {
    display: flex;
    justify-content: center;
    gap: var(--space-lg);
    flex-wrap: wrap;
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-menu li {
    margin: 0;
}

.footer-menu a {
    color: var(--text-color);
    opacity: 0.7;
    text-decoration: none;
    transition: color 0.3s ease;
    font-size: var(--font-sm);
    padding: var(--space-xs);
    min-height: var(--button-height);
    display: flex;
    align-items: center;
}

.footer-menu a:hover {
    color: var(--secondary-color);
    opacity: 1;
}

@media (max-width: 768px) {
    .footer-menu {
        flex-direction: column;
        gap: var(--space-sm);
        text-align: center;
    }
}
</style>

<?php
// Footer fallback menu function
function midnightravencasino_footer_fallback_menu() {
    echo '<div class="footer-menu">';
    echo '<a href="' . home_url('/terms') . '" class="footer-link">Terms & Conditions</a>';
    echo '<a href="' . home_url('/privacy') . '" class="footer-link">Privacy Policy</a>';
    echo '<a href="' . home_url('/cookies') . '" class="footer-link">Cookie Policy</a>';
    echo '<a href="' . home_url('/responsible') . '" class="footer-link">Responsible Social Gaming</a>';
    echo '</div>';
}
?>