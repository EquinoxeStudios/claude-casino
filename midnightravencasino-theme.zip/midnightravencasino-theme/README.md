# Midnightravencasino WordPress Theme

A luxurious casino-themed WordPress theme featuring elegant dark design with golden accents, responsive sidebar navigation, and game showcase sections.

## Features

- **Responsive Design**: Mobile-first approach with fluid typography and spacing
- **Dark Theme**: Elegant black and gold color scheme
- **Custom Post Type**: Games with provider information and play URLs
- **Sidebar Navigation**: Collapsible sidebar with smooth animations
- **Game Archive**: Dedicated games listing page with grid layout
- **Theme Customizer**: Options for hero section customization
- **SEO Optimized**: Proper semantic HTML structure
- **Accessibility**: Focus states and screen reader support
- **Security**: Hardened functions and sanitized inputs

## Installation

1. Upload the `midnightravencasino-theme` folder to `/wp-content/themes/`
2. Activate the theme through WordPress admin
3. Go to **Appearance > Customize** to configure theme options
4. Create pages and menus as needed

## Theme Structure

```
midnightravencasino-theme/
├── style.css (Main stylesheet with theme header)
├── index.php (Homepage template)
├── header.php (Header template)
├── footer.php (Footer template)
├── functions.php (Theme functionality)
├── single.php (Single post template)
├── page.php (Page template)
├── archive-game.php (Games archive template)
├── single-game.php (Single game template)
├── assets/
│   ├── css/ (Additional stylesheets)
│   ├── js/ (JavaScript files)
│   └── images/ (Theme images)
└── README.md (This file)
```

## Custom Post Types

### Games
- **Fields**: Title, Description, Featured Image, Provider, Game URL
- **Archive**: `/games/` - Grid layout with hover effects
- **Single**: Individual game pages with play button
- **Meta**: Provider name and external game URL

## Menus

The theme supports two menu locations:
- **Primary Menu**: Main sidebar navigation
- **Footer Menu**: Footer links

## Customization

### Theme Options (Customizer)
- Hero section title and description
- Hero background image
- Site logo and colors (via WordPress defaults)

### CSS Variables
The theme uses CSS custom properties for easy customization:
- Colors: `--primary-color`, `--secondary-color`, etc.
- Typography: `--font-xs` through `--font-4xl`
- Spacing: `--space-xs` through `--space-3xl`

### JavaScript Features
- Responsive sidebar toggle
- Mobile menu functionality
- Smooth animations and transitions

## Browser Support

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+
- iOS Safari 12+
- Android Chrome 60+

## Development

### Required WordPress Features
- Post thumbnails
- Custom post types
- Navigation menus
- Theme customizer
- Widgets

### PHP Requirements
- PHP 7.4 or higher
- WordPress 5.0 or higher

## Security Features

- File editing disabled
- Version number removed
- Sanitized inputs and outputs
- Nonce verification for forms
- Escaped data throughout

## Performance

- Optimized CSS with minimal redundancy
- Efficient JavaScript loading
- Responsive images
- Clean HTML structure
- Minimal external dependencies

## Support

For support and customization requests, please contact the theme developer.

## Changelog

### Version 1.0
- Initial release
- Dark casino theme design
- Games custom post type
- Responsive navigation
- Theme customizer options
- Mobile optimization

## License

This theme is licensed under GPL v2 or later.