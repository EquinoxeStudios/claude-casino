<?php get_header(); ?>

<main class="main-wrapper" id="mainWrapper">
    <?php while (have_posts()) : the_post(); ?>
        <article class="single-post">
            <header class="post-header">
                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-featured-image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="post-header-content">
                    <h1 class="post-title"><?php the_title(); ?></h1>
                    
                    <div class="post-meta">
                        <span class="post-date">
                            <i class="fas fa-calendar"></i>
                            <?php echo get_the_date(); ?>
                        </span>
                        <span class="post-author">
                            <i class="fas fa-user"></i>
                            <?php echo get_the_author(); ?>
                        </span>
                        <?php if (has_category()) : ?>
                            <span class="post-categories">
                                <i class="fas fa-folder"></i>
                                <?php the_category(', '); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <div class="post-content">
                <?php the_content(); ?>
            </div>

            <?php if (has_tag()) : ?>
                <div class="post-tags">
                    <i class="fas fa-tags"></i>
                    <?php the_tags('', ', '); ?>
                </div>
            <?php endif; ?>

            <nav class="post-navigation">
                <div class="nav-previous">
                    <?php previous_post_link('%link', '<i class="fas fa-chevron-left"></i> %title'); ?>
                </div>
                <div class="nav-next">
                    <?php next_post_link('%link', '%title <i class="fas fa-chevron-right"></i>'); ?>
                </div>
            </nav>
        </article>

        <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    <?php endwhile; ?>
</main>

<style>
.single-post {
    max-width: min(95vw, 800px);
    margin: 0 auto;
    padding: var(--space-2xl) var(--container-padding);
}

.post-header {
    margin-bottom: var(--space-2xl);
    text-align: center;
}

.post-featured-image {
    margin-bottom: var(--space-xl);
    border-radius: var(--border-radius-lg);
    overflow: hidden;
}

.post-featured-image img {
    width: 100%;
    height: auto;
    display: block;
}

.post-title {
    font-size: var(--font-4xl);
    font-weight: 900;
    margin-bottom: var(--space-lg);
    background: var(--title-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
}

.post-meta {
    display: flex;
    justify-content: center;
    gap: var(--space-lg);
    flex-wrap: wrap;
    color: var(--text-color);
    opacity: 0.7;
    font-size: var(--font-sm);
}

.post-meta span {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
}

.post-meta i {
    color: var(--secondary-color);
}

.post-content {
    font-size: var(--font-base);
    line-height: 1.8;
    color: var(--text-color);
    margin-bottom: var(--space-2xl);
}

.post-content h1,
.post-content h2,
.post-content h3,
.post-content h4,
.post-content h5,
.post-content h6 {
    margin-top: var(--space-xl);
    margin-bottom: var(--space-md);
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.post-content p {
    margin-bottom: var(--space-lg);
}

.post-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--border-radius-md);
    margin: var(--space-lg) 0;
}

.post-content blockquote {
    border-left: 4px solid var(--secondary-color);
    padding-left: var(--space-lg);
    margin: var(--space-xl) 0;
    font-style: italic;
    opacity: 0.8;
}

.post-content ul,
.post-content ol {
    padding-left: var(--space-xl);
    margin-bottom: var(--space-lg);
}

.post-content li {
    margin-bottom: var(--space-xs);
}

.post-tags {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    margin-bottom: var(--space-2xl);
    color: var(--text-color);
    opacity: 0.7;
    font-size: var(--font-sm);
    flex-wrap: wrap;
}

.post-tags i {
    color: var(--secondary-color);
}

.post-tags a {
    color: var(--text-color);
    text-decoration: none;
    padding: var(--space-xs) var(--space-sm);
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius-sm);
    transition: all 0.3s ease;
    font-size: var(--font-xs);
}

.post-tags a:hover {
    background: var(--primary-gradient);
    color: white;
}

.post-navigation {
    display: flex;
    justify-content: space-between;
    gap: var(--space-lg);
    padding-top: var(--space-xl);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.post-navigation a {
    color: var(--text-color);
    text-decoration: none;
    padding: var(--space-sm) var(--space-md);
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius-md);
    transition: all 0.3s ease;
    font-size: var(--font-sm);
    display: flex;
    align-items: center;
    gap: var(--space-xs);
    max-width: 40%;
}

.nav-previous a {
    justify-content: flex-start;
}

.nav-next a {
    justify-content: flex-end;
    margin-left: auto;
}

.post-navigation a:hover {
    background: var(--primary-gradient);
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    .post-meta {
        flex-direction: column;
        gap: var(--space-sm);
    }
    
    .post-navigation {
        flex-direction: column;
        text-align: center;
    }
    
    .post-navigation a {
        max-width: 100%;
        justify-content: center;
    }
    
    .nav-next a {
        margin-left: 0;
    }
}
</style>

<?php get_footer(); ?>