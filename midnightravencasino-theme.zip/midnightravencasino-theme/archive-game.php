<?php get_header(); ?>

<main class="main-wrapper" id="mainWrapper">
    <!-- Games Archive Header -->
    <section class="archive-header">
        <div class="archive-header-content">
            <h1 class="archive-title">
                <i class="fas fa-gamepad"></i>
                <?php post_type_archive_title(); ?>
            </h1>
            <p class="archive-description">
                Discover our complete collection of premium casino games featuring slots, table games, and live dealer experiences.
            </p>
        </div>
    </section>

    <!-- Games Grid -->
    <section class="games-section">
        <?php if (have_posts()) : ?>
            <div class="games-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="game-card">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="game-image">
                                <img src="<?php echo get_the_post_thumbnail_url(); ?>" 
                                     alt="<?php the_title(); ?>" 
                                     class="game-thumbnail" 
                                     loading="lazy">
                            </div>
                        <?php endif; ?>
                        
                        <div class="game-overlay">
                            <div class="game-info">
                                <h3 class="game-title"><?php the_title(); ?></h3>
                                
                                <?php 
                                $provider = get_post_meta(get_the_ID(), '_game_provider', true);
                                if ($provider) : ?>
                                    <div class="game-provider">
                                        <i class="fas fa-building"></i>
                                        <?php echo esc_html($provider); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (get_the_excerpt()) : ?>
                                    <div class="game-excerpt">
                                        <?php echo wp_trim_words(get_the_excerpt(), 12); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="game-actions">
                                    <?php 
                                    $game_url = get_post_meta(get_the_ID(), '_game_url', true);
                                    if ($game_url) : ?>
                                        <a href="<?php echo esc_url($game_url); ?>" 
                                           class="btn btn-primary game-play-btn"
                                           target="_blank"
                                           rel="noopener">
                                           <i class="fas fa-play"></i>
                                           Play Now
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="<?php the_permalink(); ?>" 
                                       class="btn btn-secondary game-info-btn">
                                       <i class="fas fa-info-circle"></i>
                                       Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <!-- Pagination -->
            <div class="games-pagination">
                <?php
                the_posts_pagination(array(
                    'mid_size' => 2,
                    'prev_text' => '<i class="fas fa-chevron-left"></i> Previous',
                    'next_text' => 'Next <i class="fas fa-chevron-right"></i>',
                    'screen_reader_text' => __('Games navigation', 'midnightravencasino'),
                ));
                ?>
            </div>
        <?php else : ?>
            <div class="no-games">
                <i class="fas fa-gamepad"></i>
                <h2>No Games Found</h2>
                <p>We're working on adding more games to our collection. Check back soon!</p>
            </div>
        <?php endif; ?>
    </section>
</main>

<style>
.archive-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--accent-color) 100%);
    padding: var(--space-3xl) var(--container-padding) var(--space-2xl);
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.archive-header-content {
    max-width: var(--content-max);
    margin: 0 auto;
}

.archive-title {
    font-size: var(--font-4xl);
    font-weight: 900;
    margin-bottom: var(--space-md);
    background: var(--title-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-md);
}

.archive-title i {
    color: var(--secondary-color);
    -webkit-text-fill-color: var(--secondary-color);
}

.archive-description {
    font-size: var(--font-lg);
    color: var(--text-color);
    opacity: 0.8;
    line-height: 1.6;
}

.games-section {
    padding: var(--space-2xl) var(--container-padding);
}

.games-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: var(--space-xl);
    max-width: var(--container-max);
    margin: 0 auto;
}

.game-card {
    position: relative;
    border-radius: var(--border-radius-lg);
    overflow: hidden;
    background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
    box-shadow: var(--shadow-md);
    transition: all 0.3s ease;
    cursor: pointer;
    min-height: 300px;
    display: flex;
    flex-direction: column;
}

.game-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-xl);
}

.game-image {
    position: relative;
    width: 100%;
    height: 200px;
    overflow: hidden;
}

.game-thumbnail {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.game-card:hover .game-thumbnail {
    transform: scale(1.05);
}

.game-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.1) 0%,
        rgba(0, 0, 0, 0.3) 50%,
        rgba(0, 0, 0, 0.8) 100%
    );
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: var(--space-lg);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.game-card:hover .game-overlay {
    opacity: 1;
}

.game-info {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
}

.game-title {
    font-size: var(--font-xl);
    font-weight: 700;
    color: white;
    line-height: 1.2;
    margin-bottom: var(--space-sm);
}

.game-provider {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
    color: var(--secondary-color);
    font-size: var(--font-sm);
    font-weight: 600;
}

.game-excerpt {
    color: rgba(255, 255, 255, 0.8);
    font-size: var(--font-sm);
    line-height: 1.4;
    margin-bottom: var(--space-sm);
}

.game-actions {
    display: flex;
    gap: var(--space-sm);
    margin-top: var(--space-sm);
}

.game-play-btn,
.game-info-btn {
    flex: 1;
    text-align: center;
    padding: var(--space-sm) var(--space-md);
    font-size: var(--font-sm);
    min-height: auto;
}

.game-play-btn {
    background: var(--primary-gradient);
}

.game-info-btn {
    background: rgba(255, 255, 255, 0.2);
}

.games-pagination {
    margin-top: var(--space-3xl);
    text-align: center;
}

.games-pagination .nav-links {
    display: flex;
    justify-content: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
}

.games-pagination a,
.games-pagination span {
    padding: var(--space-sm) var(--space-md);
    background: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    text-decoration: none;
    border-radius: var(--border-radius-md);
    transition: all 0.3s ease;
    min-width: var(--button-height);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
}

.games-pagination a:hover {
    background: var(--primary-gradient);
    transform: translateY(-2px);
}

.games-pagination .current {
    background: var(--primary-gradient);
}

.no-games {
    text-align: center;
    padding: var(--space-3xl) var(--container-padding);
    color: var(--text-color);
    opacity: 0.7;
}

.no-games i {
    font-size: 4rem;
    color: var(--secondary-color);
    margin-bottom: var(--space-lg);
}

.no-games h2 {
    font-size: var(--font-3xl);
    margin-bottom: var(--space-md);
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.no-games p {
    font-size: var(--font-base);
    max-width: 400px;
    margin: 0 auto;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .games-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: var(--space-lg);
    }
    
    .game-card {
        min-height: 250px;
    }
    
    .game-image {
        height: 150px;
    }
    
    .game-overlay {
        opacity: 1;
        background: linear-gradient(
            to bottom,
            rgba(0, 0, 0, 0.1) 0%,
            rgba(0, 0, 0, 0.4) 50%,
            rgba(0, 0, 0, 0.7) 100%
        );
    }
    
    .game-actions {
        flex-direction: column;
    }
    
    .archive-title {
        flex-direction: column;
        gap: var(--space-sm);
    }
}

@media (max-width: 480px) {
    .games-grid {
        grid-template-columns: 1fr;
    }
    
    .game-actions {
        flex-direction: row;
    }
}
</style>

<?php get_footer(); ?>