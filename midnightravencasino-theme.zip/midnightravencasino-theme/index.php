<?php get_header(); ?>

<main class="main-wrapper" id="mainWrapper">
    <!-- Hero Section -->
    <section class="hero" style="background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('<?php echo get_template_directory_uri(); ?>/assets/images/hero-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
        <div class="hero-content">
            <h1><?php echo get_bloginfo('description') ? get_bloginfo('description') : 'Step Into Raven Royale: The Midnight Casino Experience'; ?></h1>
            <p>Immerse yourself in an opulent gaming world where golden ravens, shimmering chandeliers, and panoramic city views set the stage for elite play.</p>
            <div class="hero-buttons">
                <a href="<?php echo home_url('/games'); ?>" class="btn btn-primary btn-large">
                    <i class="fas fa-dice"></i> Play Now
                </a>
            </div>
        </div>
    </section>

    <?php if (have_posts()) : ?>
        <!-- Dynamic Content Sections -->
        <section class="content-section">
            <div class="section-header">
                <h2 class="section-title">Latest Posts</h2>
                <p class="section-subtitle">Discover our latest news, updates, and featured content.</p>
            </div>
            
            <div class="posts-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="card">
                        <?php if (has_post_thumbnail()) : ?>
                            <img src="<?php echo get_the_post_thumbnail_url(); ?>" 
                                 alt="<?php the_title(); ?>" 
                                 class="card-thumbnail" 
                                 loading="lazy">
                        <?php else : ?>
                            <div class="card-thumbnail" style="background: linear-gradient(45deg, #1a1a1a, #2a2a2a); display: flex; align-items: center; justify-content: center; color: #666;">
                                <i class="fas fa-image" style="font-size: 2rem;"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="card-overlay">
                            <div class="card-info">
                                <h3 class="card-title"><?php the_title(); ?></h3>
                                <div class="card-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></div>
                                <a href="<?php the_permalink(); ?>" class="card-cta">
                                    Read More
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <!-- Pagination -->
            <div class="pagination-wrapper">
                <?php
                the_posts_pagination(array(
                    'mid_size' => 2,
                    'prev_text' => '<i class="fas fa-chevron-left"></i> Previous',
                    'next_text' => 'Next <i class="fas fa-chevron-right"></i>',
                ));
                ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- About Section -->
    <section class="about-section">
        <div class="about-content">
            <h2 class="section-title">About <?php bloginfo('name'); ?></h2>
            <p>Raven Royale: The Midnight Casino embodies the pinnacle of sophistication, welcoming guests to a penthouse-inspired haven of black marble and golden raven accents.</p>
            <p>Our curated selection of casino games includes high-limit tables, exclusive slots, and live-action entertainment, all served by impeccably dressed raven attendants.</p>
            <p>Join <?php bloginfo('name'); ?> today and revel in a world of premium gaming, luxury rewards, and unforgettable high-stakes thrills.</p>
        </div>
    </section>
</main>

<style>
.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: var(--card-gap);
    max-width: var(--container-max);
    margin: 0 auto;
}

.card-excerpt {
    color: rgba(255, 255, 255, 0.8);
    font-size: var(--font-sm);
    margin-bottom: var(--space-sm);
    line-height: 1.4;
}

.pagination-wrapper {
    margin-top: var(--space-2xl);
    text-align: center;
}

.pagination-wrapper .nav-links {
    display: flex;
    justify-content: center;
    gap: var(--space-sm);
    flex-wrap: wrap;
}

.pagination-wrapper a,
.pagination-wrapper span {
    padding: var(--space-sm) var(--space-md);
    background: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    text-decoration: none;
    border-radius: var(--border-radius-md);
    transition: all 0.3s ease;
    min-width: var(--button-height);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-xs);
}

.pagination-wrapper a:hover {
    background: var(--primary-gradient);
    transform: translateY(-2px);
}

.pagination-wrapper .current {
    background: var(--primary-gradient);
}

@media (max-width: 768px) {
    .posts-grid {
        grid-template-columns: 1fr;
        gap: var(--space-lg);
    }
}
</style>

<?php get_footer(); ?>