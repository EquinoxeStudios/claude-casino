<?php get_header(); ?>

<main class="main-wrapper" id="mainWrapper">
    <?php while (have_posts()) : the_post(); ?>
        <article class="single-page">
            <header class="page-header">
                <?php if (has_post_thumbnail()) : ?>
                    <div class="page-featured-image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="page-header-content">
                    <h1 class="page-title"><?php the_title(); ?></h1>
                </div>
            </header>

            <div class="page-content">
                <?php the_content(); ?>
                
                <?php
                wp_link_pages(array(
                    'before' => '<div class="page-links">' . esc_html__('Pages:', 'midnightravencasino'),
                    'after'  => '</div>',
                ));
                ?>
            </div>
        </article>

        <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    <?php endwhile; ?>
</main>

<style>
.single-page {
    max-width: min(95vw, 900px);
    margin: 0 auto;
    padding: var(--space-2xl) var(--container-padding);
}

.page-header {
    margin-bottom: var(--space-2xl);
    text-align: center;
}

.page-featured-image {
    margin-bottom: var(--space-xl);
    border-radius: var(--border-radius-lg);
    overflow: hidden;
}

.page-featured-image img {
    width: 100%;
    height: auto;
    display: block;
}

.page-title {
    font-size: var(--font-4xl);
    font-weight: 900;
    margin-bottom: var(--space-lg);
    background: var(--title-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
}

.page-content {
    font-size: var(--font-base);
    line-height: 1.8;
    color: var(--text-color);
}

.page-content h1,
.page-content h2,
.page-content h3,
.page-content h4,
.page-content h5,
.page-content h6 {
    margin-top: var(--space-xl);
    margin-bottom: var(--space-md);
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.page-content h2 {
    font-size: var(--font-3xl);
    font-weight: 800;
}

.page-content h3 {
    font-size: var(--font-2xl);
    font-weight: 700;
}

.page-content h4 {
    font-size: var(--font-xl);
    font-weight: 600;
}

.page-content p {
    margin-bottom: var(--space-lg);
}

.page-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--border-radius-md);
    margin: var(--space-lg) 0;
}

.page-content blockquote {
    border-left: 4px solid var(--secondary-color);
    padding-left: var(--space-lg);
    margin: var(--space-xl) 0;
    font-style: italic;
    opacity: 0.8;
    background: rgba(255, 255, 255, 0.05);
    padding: var(--space-lg);
    border-radius: var(--border-radius-md);
}

.page-content ul,
.page-content ol {
    padding-left: var(--space-xl);
    margin-bottom: var(--space-lg);
}

.page-content li {
    margin-bottom: var(--space-xs);
}

.page-content table {
    width: 100%;
    border-collapse: collapse;
    margin: var(--space-xl) 0;
    background: rgba(255, 255, 255, 0.05);
    border-radius: var(--border-radius-md);
    overflow: hidden;
}

.page-content th,
.page-content td {
    padding: var(--space-sm) var(--space-md);
    text-align: left;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.page-content th {
    background: var(--primary-gradient);
    color: white;
    font-weight: 600;
}

.page-content code {
    background: rgba(255, 255, 255, 0.1);
    padding: var(--space-3xs) var(--space-2xs);
    border-radius: var(--border-radius-sm);
    font-family: 'Courier New', monospace;
    font-size: var(--font-sm);
}

.page-content pre {
    background: rgba(255, 255, 255, 0.1);
    padding: var(--space-lg);
    border-radius: var(--border-radius-md);
    overflow-x: auto;
    margin: var(--space-lg) 0;
}

.page-content pre code {
    background: none;
    padding: 0;
}

.page-links {
    margin-top: var(--space-2xl);
    padding-top: var(--space-xl);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    text-align: center;
}

.page-links a,
.page-links > span {
    display: inline-block;
    padding: var(--space-sm) var(--space-md);
    margin: 0 var(--space-xs);
    background: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    text-decoration: none;
    border-radius: var(--border-radius-md);
    transition: all 0.3s ease;
}

.page-links a:hover {
    background: var(--primary-gradient);
    transform: translateY(-2px);
}

.page-links > span {
    background: var(--primary-gradient);
}

/* Special styling for contact forms */
.page-content .contact-form {
    background: rgba(255, 255, 255, 0.05);
    padding: var(--space-2xl);
    border-radius: var(--border-radius-lg);
    margin-top: var(--space-xl);
}

.page-content .contact-form input,
.page-content .contact-form textarea,
.page-content .contact-form select {
    width: 100%;
    padding: var(--space-sm) var(--space-md);
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: var(--border-radius-md);
    color: var(--text-color);
    font-size: var(--font-base);
    margin-bottom: var(--space-lg);
}

.page-content .contact-form input:focus,
.page-content .contact-form textarea:focus,
.page-content .contact-form select:focus {
    outline: none;
    border-color: var(--secondary-color);
    background: rgba(255, 255, 255, 0.15);
}

.page-content .contact-form button,
.page-content .contact-form input[type="submit"] {
    background: var(--primary-gradient);
    color: white;
    border: none;
    padding: var(--space-md) var(--space-xl);
    border-radius: var(--border-radius-md);
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    width: auto;
    margin-bottom: 0;
}

.page-content .contact-form button:hover,
.page-content .contact-form input[type="submit"]:hover {
    background: linear-gradient(45deg, var(--primary-hover), var(--secondary-hover));
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

@media (max-width: 768px) {
    .page-content table {
        font-size: var(--font-sm);
    }
    
    .page-content th,
    .page-content td {
        padding: var(--space-xs) var(--space-sm);
    }
}
</style>

<?php get_footer(); ?>