<?php
/**
 * Midnightravencasino Theme Functions
 */

// Theme setup
function midnightravencasino_setup() {
    // Add theme support for various features
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'midnightravencasino'),
        'footer' => __('Footer Menu', 'midnightravencasino'),
    ));

    // Add support for custom background
    add_theme_support('custom-background', array(
        'default-color' => '101014',
    ));
}
add_action('after_setup_theme', 'midnightravencasino_setup');

// Enqueue styles and scripts
function midnightravencasino_scripts() {
    wp_enqueue_style('midnightravencasino-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue custom JavaScript
    wp_enqueue_script('midnightravencasino-base', get_template_directory_uri() . '/assets/js/base.js', array(), '1.0.0', true);
    
    // Add theme customization script
    wp_add_inline_script('midnightravencasino-base', '
        // WordPress-specific theme enhancements
        document.addEventListener("DOMContentLoaded", function() {
            // Add active class to current menu items
            const currentPath = window.location.pathname;
            const menuLinks = document.querySelectorAll(".sidebar-menu a");
            
            menuLinks.forEach(link => {
                if (link.getAttribute("href") === currentPath || 
                    (currentPath === "/" && link.getAttribute("href") === "' . home_url() . '")) {
                    link.classList.add("active");
                }
            });
        });
    ');
}
add_action('wp_enqueue_scripts', 'midnightravencasino_scripts');

// Custom excerpt length
function midnightravencasino_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'midnightravencasino_excerpt_length', 999);

// Custom excerpt more
function midnightravencasino_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'midnightravencasino_excerpt_more');

// Widget areas
function midnightravencasino_widgets_init() {
    register_sidebar(array(
        'name'          => __('Primary Sidebar', 'midnightravencasino'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'midnightravencasino'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    register_sidebar(array(
        'name'          => __('Footer Widgets', 'midnightravencasino'),
        'id'            => 'footer-widgets',
        'description'   => __('Add footer widgets here.', 'midnightravencasino'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer-widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'midnightravencasino_widgets_init');

// Custom post type for Games
function midnightravencasino_create_game_post_type() {
    register_post_type('game',
        array(
            'labels' => array(
                'name' => __('Games', 'midnightravencasino'),
                'singular_name' => __('Game', 'midnightravencasino'),
                'add_new' => __('Add New Game', 'midnightravencasino'),
                'add_new_item' => __('Add New Game', 'midnightravencasino'),
                'edit_item' => __('Edit Game', 'midnightravencasino'),
                'new_item' => __('New Game', 'midnightravencasino'),
                'view_item' => __('View Game', 'midnightravencasino'),
                'search_items' => __('Search Games', 'midnightravencasino'),
                'not_found' => __('No games found', 'midnightravencasino'),
                'not_found_in_trash' => __('No games found in Trash', 'midnightravencasino'),
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'games'),
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'menu_icon' => 'dashicons-games',
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'midnightravencasino_create_game_post_type');

// Add custom fields for games
function midnightravencasino_add_game_meta_boxes() {
    add_meta_box(
        'game-details',
        __('Game Details', 'midnightravencasino'),
        'midnightravencasino_game_meta_box_callback',
        'game'
    );
}
add_action('add_meta_boxes', 'midnightravencasino_add_game_meta_boxes');

function midnightravencasino_game_meta_box_callback($post) {
    wp_nonce_field('midnightravencasino_save_game_meta_box_data', 'midnightravencasino_game_meta_box_nonce');
    
    $provider = get_post_meta($post->ID, '_game_provider', true);
    $game_url = get_post_meta($post->ID, '_game_url', true);
    
    echo '<table class="form-table">';
    echo '<tr><th><label for="game_provider">' . __('Game Provider', 'midnightravencasino') . '</label></th>';
    echo '<td><input type="text" id="game_provider" name="game_provider" value="' . esc_attr($provider) . '" size="25" /></td></tr>';
    echo '<tr><th><label for="game_url">' . __('Game URL', 'midnightravencasino') . '</label></th>';
    echo '<td><input type="url" id="game_url" name="game_url" value="' . esc_attr($game_url) . '" size="25" /></td></tr>';
    echo '</table>';
}

function midnightravencasino_save_game_meta_box_data($post_id) {
    if (!isset($_POST['midnightravencasino_game_meta_box_nonce'])) {
        return;
    }
    
    if (!wp_verify_nonce($_POST['midnightravencasino_game_meta_box_nonce'], 'midnightravencasino_save_game_meta_box_data')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (isset($_POST['post_type']) && 'game' == $_POST['post_type']) {
        if (!current_user_can('edit_page', $post_id)) {
            return;
        }
    } else {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    }
    
    if (isset($_POST['game_provider'])) {
        update_post_meta($post_id, '_game_provider', sanitize_text_field($_POST['game_provider']));
    }
    
    if (isset($_POST['game_url'])) {
        update_post_meta($post_id, '_game_url', esc_url_raw($_POST['game_url']));
    }
}
add_action('save_post', 'midnightravencasino_save_game_meta_box_data');

// Customizer options
function midnightravencasino_customize_register($wp_customize) {
    // Hero section
    $wp_customize->add_section('midnightravencasino_hero', array(
        'title' => __('Hero Section', 'midnightravencasino'),
        'priority' => 30,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default' => 'Step Into Raven Royale: The Midnight Casino Experience',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label' => __('Hero Title', 'midnightravencasino'),
        'section' => 'midnightravencasino_hero',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('hero_description', array(
        'default' => 'Immerse yourself in an opulent gaming world where golden ravens, shimmering chandeliers, and panoramic city views set the stage for elite play.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label' => __('Hero Description', 'midnightravencasino'),
        'section' => 'midnightravencasino_hero',
        'type' => 'textarea',
    ));
    
    $wp_customize->add_setting('hero_background', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'hero_background', array(
        'label' => __('Hero Background Image', 'midnightravencasino'),
        'section' => 'midnightravencasino_hero',
        'mime_type' => 'image',
    )));
}
add_action('customize_register', 'midnightravencasino_customize_register');

// Security enhancements
function midnightravencasino_remove_wp_version() {
    return '';
}
add_filter('the_generator', 'midnightravencasino_remove_wp_version');

// Disable file editing
define('DISALLOW_FILE_EDIT', true);

// Custom body classes
function midnightravencasino_body_classes($classes) {
    if (!is_sidebar_active('sidebar-1')) {
        $classes[] = 'no-sidebar';
    }
    
    if (is_singular('game')) {
        $classes[] = 'single-game';
    }
    
    return $classes;
}
add_filter('body_class', 'midnightravencasino_body_classes');

// Theme customization CSS
function midnightravencasino_customizer_css() {
    $hero_bg = get_theme_mod('hero_background');
    
    if ($hero_bg) {
        echo '<style type="text/css">';
        echo '.hero { background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(' . esc_url($hero_bg) . ') !important; }';
        echo '</style>';
    }
}
add_action('wp_head', 'midnightravencasino_customizer_css');
?>