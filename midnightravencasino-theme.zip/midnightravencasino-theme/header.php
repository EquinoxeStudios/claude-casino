<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/assets/images/favicon.png">
    <meta name="google" content="nopagereadaloud">
    
    <!-- Load Font properly -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer">
    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <a href="<?php echo home_url(); ?>" style="text-decoration: none; color: inherit;">
                <?php bloginfo('name'); ?>
            </a>
        </div>
    </div>
    <div class="sidebar-nav">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_class' => 'sidebar-menu',
            'container' => false,
            'fallback_cb' => 'midnightravencasino_fallback_menu'
        ));
        ?>
    </div>
    <button class="sidebar-toggle" onclick="toggleSidebar()" aria-label="Toggle sidebar">
        <i class="fas fa-chevron-left"></i>
    </button>
</nav>

<!-- Mobile Sidebar Toggle -->
<button class="mobile-sidebar-toggle" onclick="toggleMobileSidebar()" id="mobileSidebarToggle" aria-label="Open menu">
    <i class="fas fa-bars"></i>
</button>

<!-- Sidebar Overlay for Mobile -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeMobileSidebar()"></div>

<style>
/* WordPress Menu Styling */
.sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar-menu li {
    margin: 0;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    padding: var(--space-md) var(--space-lg);
    color: var(--text-color);
    opacity: 0.8;
    text-decoration: none;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
    font-size: var(--font-base);
    min-height: var(--nav-height);
    gap: var(--space-sm);
}

.sidebar-menu a:hover,
.sidebar-menu .current-menu-item a,
.sidebar-menu .current_page_item a {
    background: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    border-left-color: var(--primary-color);
    transform: translateX(var(--space-xs));
    opacity: 1;
}

.sidebar-menu a:before {
    font-family: 'Font Awesome 6 Free';
    font-weight: 900;
    font-size: var(--font-lg);
    width: var(--space-lg);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

/* Default icons for menu items */
.sidebar-menu li:first-child a:before { content: '\f015'; } /* Home */
.sidebar-menu li:nth-child(2) a:before { content: '\f11b'; } /* Games */
.sidebar-menu li:nth-child(3) a:before { content: '\f05a'; } /* About */
.sidebar-menu li:nth-child(4) a:before { content: '\f0e0'; } /* Contact */
.sidebar-menu li:nth-child(n+5) a:before { content: '\f0c1'; } /* Default for others */

/* Submenu styling */
.sidebar-menu .sub-menu {
    background: rgba(0, 0, 0, 0.2);
    padding-left: var(--space-lg);
}

.sidebar-menu .sub-menu a {
    padding-left: var(--space-xl);
    font-size: var(--font-sm);
}

.sidebar-menu .sub-menu a:before {
    content: '\f105'; /* Arrow right */
    font-size: var(--font-sm);
}
</style>

<?php
// Fallback menu function
function midnightravencasino_fallback_menu() {
    echo '<div class="sidebar-menu">';
    echo '<a href="' . home_url() . '" class="nav-item"><i class="fas fa-home"></i> <span>Home</span></a>';
    echo '<a href="' . home_url('/games') . '" class="nav-item"><i class="fas fa-gamepad"></i> <span>Games</span></a>';
    echo '<a href="' . home_url('/about') . '" class="nav-item"><i class="fas fa-info-circle"></i> <span>About Us</span></a>';
    echo '<a href="' . home_url('/contact') . '" class="nav-item"><i class="fas fa-envelope"></i> <span>Contact Us</span></a>';
    echo '</div>';
}
?>