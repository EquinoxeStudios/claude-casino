<?php get_header(); ?>

<main class="main-wrapper" id="mainWrapper">
    <?php while (have_posts()) : the_post(); ?>
        <article class="single-game">
            <header class="game-header">
                <?php if (has_post_thumbnail()) : ?>
                    <div class="game-featured-image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="game-header-content">
                    <h1 class="game-title"><?php the_title(); ?></h1>
                    
                    <div class="game-meta">
                        <?php 
                        $provider = get_post_meta(get_the_ID(), '_game_provider', true);
                        if ($provider) : ?>
                            <span class="game-provider">
                                <i class="fas fa-building"></i>
                                <?php echo esc_html($provider); ?>
                            </span>
                        <?php endif; ?>
                        
                        <span class="game-date">
                            <i class="fas fa-calendar"></i>
                            <?php echo get_the_date(); ?>
                        </span>
                    </div>
                    
                    <?php 
                    $game_url = get_post_meta(get_the_ID(), '_game_url', true);
                    if ($game_url) : ?>
                        <div class="game-play-section">
                            <a href="<?php echo esc_url($game_url); ?>" 
                               class="btn btn-primary btn-large game-play-btn"
                               target="_blank"
                               rel="noopener">
                               <i class="fas fa-play"></i>
                               Play <?php the_title(); ?> Now
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </header>

            <div class="game-content">
                <?php the_content(); ?>
            </div>

            <?php if (has_tag()) : ?>
                <div class="game-tags">
                    <i class="fas fa-tags"></i>
                    <?php the_tags('', ', '); ?>
                </div>
            <?php endif; ?>

            <!-- Game Navigation -->
            <nav class="game-navigation">
                <div class="nav-previous">
                    <?php 
                    $prev_post = get_previous_post(false, '', 'game');
                    if ($prev_post) : ?>
                        <a href="<?php echo get_permalink($prev_post->ID); ?>" class="nav-link">
                            <i class="fas fa-chevron-left"></i>
                            <div class="nav-content">
                                <span class="nav-label">Previous Game</span>
                                <span class="nav-title"><?php echo get_the_title($prev_post->ID); ?></span>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
                
                <div class="nav-center">
                    <a href="<?php echo get_post_type_archive_link('game'); ?>" class="btn btn-secondary">
                        <i class="fas fa-gamepad"></i>
                        All Games
                    </a>
                </div>
                
                <div class="nav-next">
                    <?php 
                    $next_post = get_next_post(false, '', 'game');
                    if ($next_post) : ?>
                        <a href="<?php echo get_permalink($next_post->ID); ?>" class="nav-link">
                            <div class="nav-content">
                                <span class="nav-label">Next Game</span>
                                <span class="nav-title"><?php echo get_the_title($next_post->ID); ?></span>
                            </div>
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </nav>

            <!-- Related Games -->
            <?php
            $related_games = get_posts(array(
                'post_type' => 'game',
                'posts_per_page' => 3,
                'post__not_in' => array(get_the_ID()),
                'orderby' => 'rand'
            ));
            
            if ($related_games) : ?>
                <section class="related-games">
                    <h2 class="section-title">You Might Also Like</h2>
                    <div class="related-games-grid">
                        <?php foreach ($related_games as $game) : ?>
                            <article class="related-game-card">
                                <?php if (has_post_thumbnail($game->ID)) : ?>
                                    <div class="related-game-image">
                                        <img src="<?php echo get_the_post_thumbnail_url($game->ID); ?>" 
                                             alt="<?php echo get_the_title($game->ID); ?>" 
                                             class="related-game-thumbnail">
                                    </div>
                                <?php endif; ?>
                                
                                <div class="related-game-overlay">
                                    <div class="related-game-info">
                                        <h3 class="related-game-title"><?php echo get_the_title($game->ID); ?></h3>
                                        
                                        <?php 
                                        $game_provider = get_post_meta($game->ID, '_game_provider', true);
                                        if ($game_provider) : ?>
                                            <div class="related-game-provider">
                                                <i class="fas fa-building"></i>
                                                <?php echo esc_html($game_provider); ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <a href="<?php echo get_permalink($game->ID); ?>" 
                                           class="btn btn-primary related-game-btn">
                                           <i class="fas fa-play"></i>
                                           Play Now
                                        </a>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>
        </article>

        <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    <?php endwhile; ?>
</main>

<style>
.single-game {
    max-width: min(95vw, 1000px);
    margin: 0 auto;
    padding: var(--space-2xl) var(--container-padding);
}

.game-header {
    margin-bottom: var(--space-2xl);
    text-align: center;
}

.game-featured-image {
    margin-bottom: var(--space-xl);
    border-radius: var(--border-radius-lg);
    overflow: hidden;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

.game-featured-image img {
    width: 100%;
    height: auto;
    display: block;
}

.game-title {
    font-size: var(--font-4xl);
    font-weight: 900;
    margin-bottom: var(--space-lg);
    background: var(--title-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
}

.game-meta {
    display: flex;
    justify-content: center;
    gap: var(--space-lg);
    flex-wrap: wrap;
    color: var(--text-color);
    opacity: 0.7;
    font-size: var(--font-sm);
    margin-bottom: var(--space-xl);
}

.game-meta span {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
}

.game-meta i {
    color: var(--secondary-color);
}

.game-play-section {
    margin-bottom: var(--space-xl);
}

.game-play-btn {
    font-size: var(--font-lg);
    padding: var(--space-lg) var(--space-2xl);
    min-width: 300px;
    position: relative;
    overflow: hidden;
}

.game-play-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s;
}

.game-play-btn:hover::before {
    left: 100%;
}

.game-content {
    font-size: var(--font-base);
    line-height: 1.8;
    color: var(--text-color);
    margin-bottom: var(--space-2xl);
    text-align: left;
}

.game-content h1,
.game-content h2,
.game-content h3,
.game-content h4,
.game-content h5,
.game-content h6 {
    margin-top: var(--space-xl);
    margin-bottom: var(--space-md);
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.game-content p {
    margin-bottom: var(--space-lg);
}

.game-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--border-radius-md);
    margin: var(--space-lg) 0;
}

.game-content ul,
.game-content ol {
    padding-left: var(--space-xl);
    margin-bottom: var(--space-lg);
}

.game-content li {
    margin-bottom: var(--space-xs);
}

.game-tags {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    margin-bottom: var(--space-2xl);
    color: var(--text-color);
    opacity: 0.7;
    font-size: var(--font-sm);
    flex-wrap: wrap;
}

.game-tags i {
    color: var(--secondary-color);
}

.game-tags a {
    color: var(--text-color);
    text-decoration: none;
    padding: var(--space-xs) var(--space-sm);
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius-sm);
    transition: all 0.3s ease;
    font-size: var(--font-xs);
}

.game-tags a:hover {
    background: var(--primary-gradient);
    color: white;
}

.game-navigation {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: var(--space-lg);
    align-items: center;
    padding: var(--space-xl) 0;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    margin-bottom: var(--space-2xl);
}

.nav-link {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    color: var(--text-color);
    text-decoration: none;
    padding: var(--space-sm) var(--space-md);
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius-md);
    transition: all 0.3s ease;
    max-width: 200px;
}

.nav-previous .nav-link {
    justify-content: flex-start;
}

.nav-next .nav-link {
    justify-content: flex-end;
    margin-left: auto;
}

.nav-link:hover {
    background: var(--primary-gradient);
    transform: translateY(-2px);
}

.nav-content {
    display: flex;
    flex-direction: column;
    gap: var(--space-3xs);
}

.nav-label {
    font-size: var(--font-xs);
    opacity: 0.7;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.nav-title {
    font-size: var(--font-sm);
    font-weight: 600;
    line-height: 1.2;
}

.nav-center {
    text-align: center;
}

.related-games {
    margin-top: var(--space-3xl);
}

.related-games .section-title {
    font-size: var(--font-3xl);
    font-weight: 800;
    margin-bottom: var(--space-2xl);
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-align: center;
}

.related-games-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: var(--space-xl);
}

.related-game-card {
    position: relative;
    border-radius: var(--border-radius-lg);
    overflow: hidden;
    background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
    box-shadow: var(--shadow-md);
    transition: all 0.3s ease;
    cursor: pointer;
    min-height: 200px;
}

.related-game-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-xl);
}

.related-game-image {
    width: 100%;
    height: 150px;
    overflow: hidden;
}

.related-game-thumbnail {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.related-game-card:hover .related-game-thumbnail {
    transform: scale(1.05);
}

.related-game-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.1) 0%,
        rgba(0, 0, 0, 0.6) 100%
    );
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: var(--space-md);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.related-game-card:hover .related-game-overlay {
    opacity: 1;
}

.related-game-info {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
}

.related-game-title {
    font-size: var(--font-lg);
    font-weight: 700;
    color: white;
    line-height: 1.2;
}

.related-game-provider {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
    color: var(--secondary-color);
    font-size: var(--font-sm);
    font-weight: 600;
}

.related-game-btn {
    padding: var(--space-sm) var(--space-md);
    font-size: var(--font-sm);
    width: 100%;
    text-align: center;
    margin-top: var(--space-sm);
}

@media (max-width: 768px) {
    .game-meta {
        flex-direction: column;
        gap: var(--space-sm);
    }
    
    .game-play-btn {
        min-width: auto;
        width: 100%;
        max-width: 350px;
    }
    
    .game-navigation {
        grid-template-columns: 1fr;
        gap: var(--space-md);
        text-align: center;
    }
    
    .nav-previous .nav-link,
    .nav-next .nav-link {
        justify-content: center;
        margin: 0 auto;
        max-width: 100%;
    }
    
    .related-games-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: var(--space-lg);
    }
    
    .related-game-overlay {
        opacity: 1;
        background: linear-gradient(
            to bottom,
            rgba(0, 0, 0, 0.1) 0%,
            rgba(0, 0, 0, 0.5) 100%
        );
    }
}
</style>

<?php get_footer(); ?>